<?php

use Illuminate\Support\Facades\Route;

// Route::group(['prefix' => 'adminn', 'as' => 'admin.'], function() {
//     Route::get('/home', function() {
//         return 'Admin Page';
//     })->name('home');

//     Route::get('/page1', function() {
//         return 'Admin Page';
//     })->name('page1');
//     Route::get('/page2', function() {
//         return 'Admin Page';
//     })->name('page2');
// });

// Route::group(['prefix' => 'user'], function() {
//     Route::get('/home', function() {
//         return 'User Page';
//     })->name('user.home');
// });

// Route::prefix('adminpanel')->group(function() {
//     Route::get('/home', function() {
//         return 'Admin Page';
//     });

//     Route::get('/page1', function() {
//         return 'Admin Page 1';
//     });

//     Route::get('/page2', function() {
//         return 'Admin Page 2';
//     });

//     Route::get('/page3', function() {
//         return 'Admin Page 3';
//     });

//     Route::get('/page4', function() {
//         return 'Admin Page 4';
//     });

//     Route::get('/page5', function() {
//         return 'Admin Page 5';
//     });

// });
